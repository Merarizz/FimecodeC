package com.example.profime.ui.theme

import androidx.compose.ui.graphics.Color

val verdefime = Color(0xFF034001)
val grisinactivo = Color(0xFF7F969B)
val botonverde = Color(0xFF2E7D32)

val azuloscuro = Color(0xFF0B2559)
val azulclaro = Color(0xFF183B59)
val turquesa = Color(0xFF2A5159)
val verdechillon = Color(0xFF5C8C46)

val verdebarras= Color(0xFF3F5925)
val rojorosado= Color(0xFF994D4F)
val verdehoja= Color(0xFF465633)

val verdeobscuro = Color(0xFF1D2C1C)
val verdegris = Color(0xFF8EA185)
val verdemilitar= Color(0xFF2E5902)

val azul= Color(0xFF46658C)

val blanco = Color(0xFFFFFFFF)
val negro = Color(0xFF000000)

